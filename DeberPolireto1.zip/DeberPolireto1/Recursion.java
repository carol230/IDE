/**
 * RECURSION
 * @author: Alexis Bautista
 * @since: 04/12/2023
 * @version: 1.0
 */
public class Recursion {
        // Método recursivo para calcular el factorial
        public long Factorial(int n) {
            // Caso base: factorial e 0 es 1
            if (n == 0 || n == 1) {
                return 1;
            } else {
                // Caso recursivo: n * factorial(n-1)
                return n * Factorial(n-1);
            }
        }
    
        public void Factorial() {
    
            System.out.println("\n RECURSION 1");
            System.out.print("Ingrese el numero a calcular su factorial: ");
            String num = debermain.scTerminos.nextLine();
            int numero =Integer.parseInt(num);
    
            // Verificación para números negativos
            if (numero < 0) {
                System.out.println("No existe el factorial para números negativos.");
            } else {
                // Llamada al método y muestra del resultado
                long factorial = Factorial(numero);
                System.out.println("El factorial de " + numero + " es: " + factorial);
            }
        }
}

