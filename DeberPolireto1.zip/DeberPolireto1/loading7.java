public class loading7 {

    public static void main(String[] args) {
        System.out.println("\nLOADING 07\n ");
        int total3 = 20; // Total de caracteres en la barra
        int progress3 = 5; // Porcentaje de progreso inicial
        // Imprimir la barra de progreso inicial
        printProgressBar3(progress3, total3);

        // Simular el progreso cambiando la punta con movimiento rotacional
        for (int i = 0; i < 100; i += 5) {
            try {
                Thread.sleep(500); // Simular alguna tarea que toma tiempo
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            progress3 += 5;
            progress3 = progress3 % (total3 + 1); // Asegurar que la punta se mueva de izquierda a derecha
            printProgressBar3(progress3, total3);
        }
    }

    private static void printProgressBar3(int progress3, int total3) {
        System.out.print("\r[");
        for (int i = 0; i < total3; i++) {
            if (i == progress3) {
                switch (i % 4) {
                    case 0:
                        System.out.print("\\");
                        break;
                    case 1:
                        System.out.print("|");
                        break;
                    case 2:
                        System.out.print("/");
                        break;
                    case 3:
                        System.out.print("-");
                        break;
                }
            } else if (i < progress3) {
                System.out.print("=");
            } else {
                System.out.print(" ");
            }
        }
        System.out.print("] " + progress3 + "%");
    }
}
