import java.util.Scanner;

public class serie11 {

    private static int obtenerNumeroTerminos() {
        Scanner sc = new Scanner(System.in);
        System.out.print("\nIntroduce un número entero: ");
        return sc.nextInt();
    }

    // Serie usando bucle for
    public void procesofor() {
        System.out.print("\nSerie usando bucle for:");
        int numterminos = obtenerNumeroTerminos();
        int a;
        for (int i = 1; i <= numterminos; i++) {
            a = i * (i + 1);
            System.out.print(" - " + a);
        }
    }

    // Serie usando bucle do while
    public void procesodowhile() {
        System.out.print("\n\nSerie usando bucle do while:");
        int numterminos = obtenerNumeroTerminos();
        int a;
        int i = 1;
        do {
            a = i * (i + 1);
            i++;
            System.out.print(" - " + a);
        } while (i <= numterminos);
    }

    public void procesowhile(){
    System.out.print("\nSerie usando bucle while");
    int numterminos = obtenerNumeroTerminos();
        int a = 2;
        int i = 1;
        while (i <= numterminos) {
            a = i * (i + 1);
            i++;
            System.out.print(" " + a);
        }
    }
    public static void main(String[] args) throws Exception {
        serie11 oserie11 = new serie11();
        oserie11.procesofor();
        oserie11.procesodowhile();
        oserie11.procesodowhile();
    }
}
