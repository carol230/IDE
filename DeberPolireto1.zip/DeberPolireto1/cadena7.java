import java.util.Scanner;

public class cadena7 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un valor numérico: ");
        int n = scanner.nextInt();
        
        // Call the cadena7 method and print the result
        System.out.println(cadena7(n));
    }

    // Define the cadena7 method outside the main method
    public static String cadena7(int n) {
        StringBuilder resultado = new StringBuilder();
        char letra = 'a';
        for (int i = 1; i <= n; i++) {
            for (int j = 0; j < 2 * i; j++) {
                resultado.append(letra);
            }
            resultado.append(" ");
            letra++;
        }
        return resultado.toString();
    }
}
