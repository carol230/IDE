/**
 * @author: Ivonne Ayala
 * @version: 1.0
 */
import java.util.Scanner;
public class Figura10 {
    public static void imprimirFigura10(){
        System.out.println("Figura 10: ");

        // Crea un objeto Scanner para leer la entrada del usuario
        Scanner scanner=new Scanner(System.in);
        System.out.print("Ingrese el numero de niveles: ");
        
        // Lee el número de niveles ingresado por el usuario
        int niveles=scanner.nextInt();

        // Imprime la parte superior de la figura
        System.out.println("_+_");

        // Imprime las capas de la figura descendente
        for (int i=0;i<niveles;i++){
            // Imprime espacios en blanco antes de la barra
            for (int j=0;j<=i;j++){
                System.out.print("    ");
            }

            // Decide qué tipo de patron imprimir
            if (i%2==0){
                System.out.println("|_-_");
            }else{
                System.out.println("|_+_");
            }
        }
        System.out.println("\n");
    }
    public static void main(String[] args) {
        imprimirFigura10();
    }
}

