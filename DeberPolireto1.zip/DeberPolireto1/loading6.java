public class loading6 {

    public static void main(String[] args) {
        System.out.println("\nLOADING 06\n ");
        int total2 = 20; // Total de caracteres en la barra
        int progress2 = 5; // Porcentaje de progreso inicial
        // Imprimir la barra de progreso inicial
        printProgressBar2(progress2, total2);
        // Simular el progreso cambiando la posición de la barra
        for (int i = 0; i < 100; i++) {
            try {
                Thread.sleep(100); // Simular alguna tarea que toma tiempo
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            progress2 += 1;
            progress2 = progress2 % (total2 * 2); // Hacer que la barra se desplace de izquierda a derecha
            printProgressBar2(progress2, total2);
        }
    }

    public static void printProgressBar2(int progress2, int total2) {
        System.out.print("\r[");
        for (int i = 0; i < total2; i++) {
            if (i == progress2 || i == total2 + progress2) {
                System.out.print("<=");
                System.out.print("=>");
            } else {
                System.out.print(" ");
            }
        }
        System.out.print("] " + progress2 + "%");
    }
}
