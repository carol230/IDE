/**
 * @author: Ivonne Ayala
 * @version: 1.0
 */
import java.util.Scanner;
public class SerieSeis {
    public static void charSerieSeis() {
        System.out.println("Serie 6: ");
        // Crea un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el numero de elementos: ");
        int tamanio = scanner.nextInt();
        // El bucle se define a través del rango de caracteres ASCII 'a' hasta que sea menor a 'a + tamanio'
        for(char i=97;i<97+tamanio;i++){ 
            // Imprime el carácter actual
            System.out.print(i + " ");
        }
        System.out.println("\n");
    }
}