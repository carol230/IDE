/**
 * @author: Ivonne Ayala
 * @version: 1.0
 */
import java.util.Scanner;
public class Recursion3 {
    public static void multi() {
        System.out.println("\n Recursion 3: ");
         // Crea un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el primer valor: ");
        int a = scanner.nextInt();
        System.out.print("Ingrese el segundo valor: ");
        int b=scanner.nextInt();
        // Llama al método de multiplicación y almacena el resultado
        int resultado = multiplicacion(a,b);
        // Imprime el resultado de la multiplicación
        System.out.println("Total= " + resultado);
        System.out.println("\n");
    }
    private static int multiplicacion(int a, int b) {
        // Caso base: si b es 0, el resultado es 0
        if (b==0) {
            return 0;
        }
        // Llamada recursiva: suma 'a' repetidamente 'b' veces
        return a + multiplicacion(a, b - 1);
    }
}

// 16= 4+8  
//       4+4
//         4+0