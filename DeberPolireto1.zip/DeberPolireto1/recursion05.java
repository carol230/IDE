import java.util.Scanner;

public class recursion05 {

    public static void imrecursion05() {
        System.out.print("\nRecursion 05:");
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nIngresa un número para el conteo regresivo: ");

        int numeroInicial = scanner.nextInt();

        // Llamar al método para realizar el conteo regresivo
        conteoRegresivo(numeroInicial);
    }

    // Método privado que realiza el conteo regresivo de manera recursiva
    private static void conteoRegresivo(int n) {
        // Verificar si el número es menor que 0, en cuyo caso se imprime un mensaje y se termina la recursión
        if (n < 0) {
            System.out.println("Conteo finalizado");
        } else {
            // Imprimir el valor actual del conteo
            System.out.println("Conteo: " + n);

            // Llamar recursivamente al mismo método con el siguiente número
            conteoRegresivo(n - 1);
        }
    }

    // Método principal donde se inicia la ejecución del programa
    public static void main(String[] args) {
        // Llamar al método público que inicia el conteo regresivo
        recursion05.imrecursion05();
    }
}
