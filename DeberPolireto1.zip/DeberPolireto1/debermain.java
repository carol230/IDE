	import java.util.InputMismatchException;
	import java.util.Scanner;

	public class debermain {
		public static Scanner scTerminos = new Scanner(System.in);
		public static void main(String[] args) {
			// TODO Auto-generated method stub

			System.out.println("Grupo: Uno");
			System.out.println("Integrantes: Ivonne Ayala, Leandor Alava, Andree Silva, Alexis Bautista, Sebastian Bravo ");


			Scanner sn = new Scanner(System.in);
			boolean salir = false;
			int opcion; 
			SerieCinco oSerieCinco;
			//SerieSeis oSerieSeis;


			do{
				System.out.println();
				System.out.println("1. Series numericas");
				System.out.println("2. Serie de caracteres");
	            System.out.println("3. Serie de Figuras"); //niveles
	            System.out.println("4. Cadena de caracteres");
             	System.out.println("5. Arrays");
	            System.out.println("6. Loading");
	            System.out.println("7. Recursion");
                System.out.println("8. Salir");

				try {
                System.out.println("");
                opcion = sn.nextInt();

                switch (opcion) {
                    case 1:

                        System.out.println("1. Series numericas");
                        System.out.println("Cuantos elementos desea?");
						int nroTerminos = sn.nextInt();
						System.out.println();
						System.out.println("\nSERIE 5: ");
						serie5 oSerie5= new serie5();
						oSerie5.showSerie5();
						serie6 oSerie6= new serie6();
						oSerie6.showSerie6();
        				Serie7 oSerie7 = new Serie7();

        				System.out.println("Serie con ciclo For");
       					 oSerie7.serie7For(nroTerminos);

        				System.out.println();
        				System.out.println("Serie con ciclo While");
        				oSerie7.serie7While(nroTerminos);

        				System.out.println();
       					System.out.println("Serie con ciclo Do-While");
        				oSerie7.serie7Dowhile(nroTerminos);

        				System.out.println();
        				System.out.println();
        				System.out.println("SERIE 8");
        				Serie8 oSerie8 = new Serie8();

        				System.out.println("Serie con ciclo For");
        				oSerie8.serie8For(nroTerminos);

       					System.out.println();
       					System.out.println("Serie con ciclo While. ");
       					oSerie8.serie8While(nroTerminos);


                        //int agregar = 0;

                        //try {
                        //    System.out.println("");
                        //    agregar = sn.nextInt();
                        //} catch (InputMismatchException f) {
                        //    System.out.println("Debes insertar numeros enteros");
                        //    sn.next();
                        //}
						break;

					case 2:
					System.out.println("2. Serie de Caracteres");
					SeriesCaracteres oSeriesCaracteres = new SeriesCaracteres();
			        oSeriesCaracteres.serieCaracteres1();
        			oSeriesCaracteres.serieCaracteres2();
					SerieCinco.charSerieCinco();
					SerieSeis.charSerieSeis();
					SerieSeis2.charSerieSeis2();
        			serie09 serie09 = new serie09();
        			serie09.generarSerie();

                        break;
					
					case 3:
					System.out.println("3. Serie de Figuras");
					System.out.println();
    				Figuras oFiguras = new Figuras();
        			oFiguras.Figura1();
        			oFiguras.Figura2();
        			oFiguras.Figura3();
        			oFiguras.Figura4();
					Figura9.imprimirFigura9();
					Figura10.imprimirFigura10();
					Figura11.imprimirFigura11();
					figura15.imfigura15();
					figura16.imfigura16();
					figura17.imfigura17();
        			figura18.imfigura18();
					figura19.imfigura19();
					break;

					case 4:
					System.out.println("4. Cadena de Caracteres");
					System.out.println();
					CadenaCaracteres oCadenaCaracteres = new CadenaCaracteres();
        			oCadenaCaracteres.Cadena1();
        			oCadenaCaracteres.Cadena2();
					Cadena5.cadena5();
					Cadena6.cadena6();
					cadena09.imcadena09();
					break;

					case 5:
					System.out.println("5. Arrays");
					System.out.println();
					Arreglos oArreglo = new Arreglos();
       				oArreglo.Arreglo1();
					Array3.main();

					case 6:
					System.out.println("6. Loading");
					System.out.println();
					Loadings oLoadings = new Loadings();
					oLoadings.Loading1();
					Loading3.loading3();
					Loading4.loading4();
					cargando09 ocargando09 = new cargando09();
        			ocargando09.imcargando09();
					cargando10 ocargando10 = new cargando10();
        			ocargando10.imcargando10();
					cargando11 ocargando11 = new cargando11();
       				 ocargando11.imcargando11();
					break;

					case 7:
					System.out.println("7. Recursion");
					System.out.println();
					Recursion oRecursion = new Recursion();
					oRecursion.Factorial(); 
					Recursion3.multi();
					recursion05.imrecursion05();
					Recursion6.main();;
        			
       
					break;
                    case 8:
                        salir = true;
                        break;

                    default:
                        System.out.println("Solo números entre 1 y 8");
                }
            } catch (InputMismatchException e) {
                System.out.println("Debes insertar un número entero. ");
                sn.next();
            }

        } while (!salir);
    }
}
	
		

