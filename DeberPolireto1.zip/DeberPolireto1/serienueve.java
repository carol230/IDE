import java.util.Scanner;

public class serienueve {

    private static int obtenerNumeroTerminos() {
        Scanner sc = new Scanner(System.in);
        System.out.print("\nIntroduce un número entero: ");
        return sc.nextInt();
    }

    public void procesofor() {
        System.out.print("\n\nSerie usando bucle for:");
        int numterminos = obtenerNumeroTerminos();
        int a = 2;
        for (int i = 1; i <= numterminos; i++) {
            System.out.print(" - " + a);
            a += 2;
        }
    }

    public void procesodowhile() {
        System.out.print("\n\nSerie usando bucle do while:");
        int numterminos = obtenerNumeroTerminos();
        int a = 2;
        int i = 1;
        do {
            System.out.print(" - " + a);
            a += 2;
            i++;
        } while (i <= numterminos);
    }

    // serie usando while
    public void procesowhile() {
        System.out.print("\n\nSerie usando bucle while:");
        int numterminos = obtenerNumeroTerminos();
        int a = 2;
        int i = 1;
        while (i <= numterminos) {
            System.out.print(" - " + a);
            a += 2;
            i++;
        }
    }

    public static void main(String[] args) throws Exception {

        serienueve oSerienueve = new serienueve();
        oSerienueve.procesofor();
        oSerienueve.procesodowhile();
        oSerienueve.procesowhile();
    }
}
