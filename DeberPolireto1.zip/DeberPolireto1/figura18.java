import java.util.Scanner;

public class figura18 {

    public static void imfigura18() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nFigura 18:");
        System.out.print("\nIngrese el número de términos: ");
        int numterminos = scanner.nextInt();
        // Crear un arreglo bidimensional para almacenar los valores
        int[][] triangulo = new int[numterminos][numterminos];

        // Llenar el arreglo con los valores de la serie
        for (int i = 0; i < numterminos; i++) {
            triangulo[i][0] = 1; // El primer elemento siempre es 1
            triangulo[i][i] = 2; // El último elemento siempre es 2
            int valorAnterior = 1;

            // Calcular los valores intermedios
            for (int j = 1; j < i; j++) {
                triangulo[i][j] = valorAnterior + triangulo[i - 1][j];
                valorAnterior = triangulo[i - 1][j];
            }
        }

        // Imprimir el patrón
        for (int i = 0; i < numterminos; i++) {
            for (int j = 0; j <= i; j++) {
                System.out.print(triangulo[i][j] + "   ");
            }
            System.out.println(); // Salto de línea después de cada fila
        }
    }

    public static void main(String[] args) {
        imfigura18();
    }
}
