/**
 * @author: Ivonne Ayala
 * @version: 1.0
 */
import java.util.Scanner;
public class Loading3 {
    public static void loading3(){
        System.out.println("\n Loading 3: ");

        // Crea un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un carácter: ");
        // Lee el carácter ingresado por el usuario
        char caracter = scanner.next().charAt(0);

        // El bucle esta definido a través de 21 pasos para simular el progreso de la carga
        for(int i=1;i<=21;i++){
            // Imprime el indicador de carga en la misma línea usando \r 
            System.out.print("\r[");
            // Imprime caracteres en función del progreso
            for (int j=1;j<=20;j++) {
                if (j<i){
                    System.out.print(caracter);
                } else {
                    System.out.print(" ");
                }
            }
            // Imprime la etiqueta de porcentaje
            System.out.print("] "+((i-1) * 5)+"%");
             // Pausa la ejecución durante 100 milisegundos para simular la actualización del indicador
            {
                try{
			        Thread.sleep(100);
		            }catch(InterruptedException e){
			            e.printStackTrace();
		            }
	        }
           
        }
        System.out.println("\n");
    }
    public static void main(String[] args) {
        loading3();
    }

}

