/**
 * CADENAS DE CARACTERES
 * @author: Alexis Bautista
 * @since: 04/12/2023
 * @version: 1.0
 */
public class CadenaCaracteres {

    public void Cadena1(){

        //Ingreso de datos
        System.out.println("\nCADENA 1");
        System.out.println("Ingrese una frase: ");
        String frase = debermain.scTerminos.nextLine();

        //contador de  vocales
        int contVocales=0;  
        for(int i=0;i<frase.length();i++){ //Contar los caracteres ingresados
            char caracter = Character.toLowerCase(frase.charAt(i)); //Convertir a minusculas
            if (caracter =='a' || caracter == 'e'|| caracter == 'i'|| caracter == 'o'|| caracter == 'u'){
            contVocales++;
            }
        }
        System.out.println("La frase: "+frase+"  tiene " +contVocales + " vocales");
    }

    public void Cadena2(){
        //Ingreso de datos
        System.out.println("\nCADENA 2");
        System.out.println("Ingrese una frase: ");
        String frase = debermain.scTerminos.nextLine();

        //contador de letras
        int contLetras=0;  
        for(int i=0;i<frase.length();i++){ //Contar los caracteres ingresados
            char caracter = Character.toLowerCase(frase.charAt(i)); //Convertir a minusculas
            if (caracter !='a' && caracter != 'e' && caracter != 'i' && caracter != 'o' && caracter != 'u' && caracter !=' '){
            contLetras++;
            }
        }
        System.out.println("La frase: "+frase+ " tiene " +contLetras + " letras");
        
    }
}