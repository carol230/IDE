import java.util.Scanner;

public class cadena8 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un valor numérico: ");
        int n = scanner.nextInt();
        
        // Call the cadena7 method and print the result
        System.out.println(cadena8(n));
    }

    public static String cadena8 (int n) {
        StringBuilder resultado = new StringBuilder();
        char letra = 'a';
        for (int i = 1; i <= n; i++) {
            for (int j = 0; j < 3 * i; j++) {
                if (j % 2 != 0) {
                    resultado.append(letra);
                }
            }
            if (i < n) {
                resultado.append(" "); 
            }
            letra++;
        }
        return resultado.toString();
    }
}