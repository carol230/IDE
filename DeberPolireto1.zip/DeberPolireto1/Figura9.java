/**
 * @author: Ivonne Ayala
 * @version: 1.0
 */
import java.util.Scanner;
public class Figura9 {
    public static void imprimirFigura9(){
        System.out.println("Figura 9: ");
        // Crea un objeto Scanner para leer la entrada del usuario
        Scanner scanner=new Scanner(System.in);
        
        System.out.print("Ingrese el numero de niveles: ");
        // Lee el número de niveles ingresado por el usuario
        int niveles=scanner.nextInt();

        // Imprime la parte superior de la figura
        for (int i=0;i<niveles;i++){
            System.out.print("   ");
        }
        System.out.println("___");

        // Imprime las capas de la figura descendente
        for (int i=0;i<niveles;i++){
            // Imprime espacios en blanco antes de la barra inicial
            for (int j=0;j<niveles-i-1;j++){
                System.out.print("   ");
            }
            
            // Imprime la barra inicial
            System.out.print("___| ");

            // Imprime espacios en blanco entre las barras
            for (int j=0;j<2*i;j++){
                System.out.print("   ");
            }

            // Imprime la barra final
            System.out.println(" |___");
        }
        System.out.println("\n");
    }
    public static void main(String[] args) {
        imprimirFigura9();
    }
}
