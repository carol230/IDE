import java.util.Scanner;

public class figura12 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un valor numérico: ");
        int n = scanner.nextInt();
        generarFigura12(n);
    }
    public static void generarFigura12(int n) {
        System.out.println("\nFIGURA 12\n");
        for (int i = n; i >= 1; i--) {
            for (int j = 1; j <= i; j++) {
                System.out.print(j);
            }
            System.out.println();
        }
    }
}
