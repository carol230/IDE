import java.util.Scanner;

public class cargando10 {

    public void imcargando10() {
        System.out.print("\nCargando 10:");
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nIngrese su nombre completo:");
        String nombreCompleto = scanner.nextLine();

        // Mostrar la carga letra por letra
        System.out.println("Cargando:");
        for (int i = 0; i <= nombreCompleto.length(); i++) {
            try {
                Thread.sleep(100); // Simula una pausa para la carga
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // Mostrar el nombre con una letra adicional
            System.out.print("\t" + cargarNombre(nombreCompleto, i) + "  \t" + i * 100 / nombreCompleto.length() + "%\n");
        }

        // Mostrar mensaje de carga completa
        System.out.println("\nCarga completa. ¡Hola, " + nombreCompleto + "!");
    }

    // Función que devuelve el nombre con una letra adicional en función de la posición actual
    private static String cargarNombre(String nombreCompleto, int posicionActual) {
        return nombreCompleto.substring(0, Math.min(posicionActual, nombreCompleto.length()));
    }

    public static void main(String[] args) {
        cargando10 ocargando10 = new cargando10();
        ocargando10.imcargando10();
    }
}
