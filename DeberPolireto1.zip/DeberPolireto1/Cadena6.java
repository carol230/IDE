/**
 * @author: Ivonne Ayala
 * @version: 1.0
 */
import java.util.Scanner;
public class Cadena6{
    public static void cadena6(){
        System.out.println("\n Cadena 6: ");
        // Crea un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese una frase: ");
        // Lee la frase ingresado por el usuario
        String frase = scanner.nextLine();

        // Crea un objeto StringBuilder a partir de la frase.Le da la vuelta y lo deja en mayusculas
        StringBuilder resultado = new StringBuilder(frase.toUpperCase()).reverse();

        // El bucle se define sobre cada carácter en el resultado invertido
        for (int i = 0; i < resultado.length(); i++){
            char c = resultado.charAt(i);
            // Convierte el carácter a minúscula y verifica si es una vocal
            switch (Character.toLowerCase(c)){
                case 'a':
                case 'e':
                case 'i':
                case 'o':
                case 'u':
                // Si es una vocal, convierte el carácter a minúscula
                    resultado.setCharAt(i,Character.toLowerCase(c));
                    break;
            }
        }
        System.out.println(resultado);
        System.out.println("\n");
    }
    public static void main(String[] args) {
        cadena6();
    }
}
