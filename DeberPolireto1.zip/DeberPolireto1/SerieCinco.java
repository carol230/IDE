/**
 * @author: Ivonne Ayala
 * @version: 1.0
 */
import java.util.Scanner;
public class SerieCinco {
    public static void charSerieCinco(){
        // Crea un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el numero de elementos: ");
        int tamanio = scanner.nextInt();

        System.out.println("\nSerie 5:");
        // Conjunto de símbolos predefinidos en un arreglo
        String simb[]={ "\\","|","/","-","|"};

        for (int i=0; i<tamanio; i++) {
            // Imprime el símbolo actual en la posición i % longitud del arreglo de símbolos
            System.out.print(simb[i%simb.length] + " ");
        }
        System.out.println("\n");
    }
}
