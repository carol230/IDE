/**
 * FUGURAS
 * @author: Alexis Bautista
 * @since: 04/12/2023
 * @version: 1.0
 */
public class Figuras {

        public void Figura1(){
        //Declaracion de variables
        char caracter = '*';

        //Ingreso de datos
        System.out.println("\nFigura 1");
        System.out.println("Ingrese el tamaño de la figura: ");
        String tamaño = debermain.scTerminos.nextLine();

        //Operacion
        int tam =Integer.parseInt(tamaño);
        for (int i = 0; i < tam; i++){
            for (int j = 0; j < tam; j++) {
                if (i == 0 || i == tam - 1 || j == 0 || j == tam - 1) { //comprobar en que espacios imprimir *
                    System.out.print(caracter + " ");
                } else {
                    System.out.print("  "); // Espacios en blanco para el interior de la figura
                }
            }
            System.out.println();
        }   
    }

    public void Figura2(){
        char aster = '*', mas = '+';

        //Ingreso de datos
        System.out.println("\nFigura 2");
        System.out.println("Ingrese el tamaño de la figura: ");
        String tamaño = debermain.scTerminos.nextLine();

        //Operacion
        int tam =Integer.parseInt(tamaño);
        for (int i = 0; i < tam; i++){
            for (int j = 0; j < tam; j++) {
                if (i == 0 || i == tam - 1 || j == 0 || j == tam - 1) {
                    if (i % 2 == 0 && j % 2 == 0) {  //Comprobar si es par o impar para imprimir * o +
                        System.out.print(aster + " ");
                    }
                    else{
                        System.out.print(mas + " ");
                    }
                } 
                else 
                    System.out.print("  "); // Espacios en blanco para el interior de la figura
            }
            System.out.println();
        }
    }

    public void Figura3(){
        char caracter = '*';

        //Ingreso de datos
        System.out.println("\nFigura 3");
        System.out.println("Ingrese el tamaño de la figura: ");
        String tamaño = debermain.scTerminos.nextLine();

        //Operacion
        for (int i = 0; i < Integer.parseInt(tamaño); i++) {
            for (int j = 0; j <= i; j++) {
                System.out.print(caracter);
            }
            System.out.println();
        }
    }

    public void Figura4(){
        char caracter = '*';

        //Ingreso de datos
        System.out.println("\nFigura 4");
        System.out.println("Ingrese el tamaño de la figura: ");
        String tamaño = debermain.scTerminos.nextLine();

        //Operacion
        for (int i = 0; i < Integer.parseInt(tamaño); i++) {
            for (int j = 0; j <Integer.parseInt(tamaño)- i - 1  ; j++) {
                System.out.print(" ");
            }

            for (int k = 0; k <= i; k++) {
                System.out.print(caracter);
            }
            System.out.println();
        }
    
    }
    public static void main(String[] args) {
        
    }
    
}

