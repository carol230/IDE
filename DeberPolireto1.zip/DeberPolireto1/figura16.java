import java.util.Scanner;

public class figura16 {

    // Método para formar el patrón en forma de "X"
    public static void imfigura16() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nFigura 16: ");
        System.out.print("\nIngrese el tamaño de la figura: ");
        int tamano = scanner.nextInt();
        int espacios = 4;  // Número de espacios entre los signos

        // Bucle externo para iterar sobre las filas
        for (int i = 1; i <= tamano; i++) {
            // Bucle interno para iterar sobre las columnas
            for (int j = 1; j <= tamano; j++) {
                // Verificar si la posición actual corresponde a un signo en la "X"
                if (j == i || j == tamano - i + 1) {
                    // Alternar entre "1" y "0" basado en la paridad de la fila
                    System.out.print((i % 2 == 0) ? " - " : " + ");
                } else {
                    // Imprimir espacios solo si no se está imprimiendo un número
                    for (int k = 1; k <= espacios; k++) {
                        System.out.print(" ");
                    }
                }
            }
            // Nueva línea después de imprimir una fila completa
            System.out.println();
        }
    }

    public static void main(String[] args) {
    
        imfigura16();
    }
}
