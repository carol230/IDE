/**
 * ARRAYS
 * @author: Alexis Bautista
 * @since: 04/12/2023
 * @version: 1.0
 */
public class Arreglos {

    public void Arreglo1(){
        //Declaracion de ARRAYS
        char nom1[] = {'A', 'l', 'e', 'x', 'i', 's'};
        char nom2[] = {'F', 'e', 'r', 'n', 'a', 'n', 'd', 'o'};
        char apell1[] = {'B', 'a', 'u', 't', 'i', 's', 't', 'a'};
        char apell2[] = {'M', 'i', 'ñ', 'o'};

        //Ingreso de datos
        System.out.println("\nARRAY 1");
        System.out.println("El nombre a presentar es ALEXIS FERNANDO BAUTISTA MIÑO");
        System.out.println("Ingrese el porcentaje de carga para el primer nombre: ");
        String porcnom1 = debermain.scTerminos.nextLine();
        System.out.println("Ingrese el porcentaje de carga para el segundo nombre: ");
        String porcnom2 = debermain.scTerminos.nextLine();
        System.out.println("Ingrese el porcentaje de carga para el primer apellido: ");
        String porcapell1 = debermain.scTerminos.nextLine();
        System.out.println("Ingrese el porcentaje de carga para el segundo apellido: ");
        String porcapell2 = debermain.scTerminos.nextLine();

        //Transformar
        int porcNom1 = Integer.parseInt(porcnom1);
        int porcNom2 = Integer.parseInt(porcnom2);
        int porcApell1 = Integer.parseInt(porcapell1);
        int porcApell2 = Integer.parseInt(porcapell2);

        // Calcular la longitud de cada subcadena
        int longitudNom1 = (nom1.length * porcNom1) / 100;
        int longitudNom2 = (nom2.length * porcNom2) / 100;
        int longitudApell1 = (apell1.length * porcApell1) / 100;
        int longitudApell2 = (apell2.length * porcApell2) / 100;

        // Imprimir la barra de carga y el nombre correspondiente
        System.out.println(generarBarraCarga(porcNom1) + " " + porcNom1 + "% " + new String(nom1, 0, longitudNom1));
        System.out.println(generarBarraCarga(porcNom2) + " " + porcNom2 + "% " + new String(nom2, 0, longitudNom2));
        System.out.println(generarBarraCarga(porcApell1) + " " + porcApell1 + "% " + new String(apell1, 0, longitudApell1));
        System.out.println(generarBarraCarga(porcApell2) + " " + porcApell2 + "% " + new String(apell2, 0, longitudApell2));
   
    }

    public static String generarBarraCarga(int porcentaje) {
        int numBloques = porcentaje / 10;
        StringBuilder barra = new StringBuilder("[");
        for (int i = 0; i < 10; i++) {
            if (i < numBloques) {
                barra.append("=");
            } else {
                barra.append(" ");
            }
        }
        barra.append("]");
        return barra.toString();
    }
}
