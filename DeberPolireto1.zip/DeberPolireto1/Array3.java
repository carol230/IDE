/**
 * @author: Ivonne Ayala
 * @version: 1.0
 */
import java.util.Scanner;
public class Array3 {
    
    public static void main(){
        System.out.println("\n Array 3: ");
        // Crea un objeto Scanner para leer la entrada del usuario
        Scanner scanner=new Scanner(System.in);
        System.out.print("Ingresa tu nombre: ");
        // Lee el nombre ingresado por el usuario
        String nombre=scanner.nextLine();

        // Convierte el nombre a un arreglo de caracteres
        char[] caracteresNombre=nombre.toCharArray();

        // Calcula el tamaño de la matriz basado en la longitud del nombre y le suma 3
        int tamanio=caracteresNombre.length+3;

        // Crea una matriz de caracteres con el tamaño calculado
        char[][] matriz=new char[tamanio][tamanio];

        // Inicializa la matriz con espacios en blanco
        for (int i=0;i<tamanio;i++){
            for (int j=0;j<tamanio;j++){
                matriz[i][j] = ' ';
            }
        }

        // Dibuja las columnas verticales y la línea horizontal en la matriz
        for (int i=1;i<tamanio;i++){
            matriz[i][1]='|';
            matriz[tamanio-1][i] ='-';
        }

        // Asigna valores ascendentes a la primera columna de la matriz
        for (int i=tamanio-2,valor='1';i>0;i--,valor++){
            matriz[i][0]=(char)valor;
        }

        // Coloca los caracteres del nombre en la posición adecuada de la matriz
        for (int i=0;i<caracteresNombre.length;i++){
            int y=i+1;
            int x=tamanio-3-i;

            // Verifica que las coordenadas estén dentro de los límites de la matriz
            if (x<tamanio && y<tamanio){
                matriz[x][y]=caracteresNombre[i];
            }
        }

        // Imprime la matriz
        for (int i=0;i<tamanio;i++){
            for (int j=0;j<tamanio;j++){
                System.out.print(matriz[i][j]+" ");
            }
            System.out.println();
        }
        System.out.println("\n");
    }
    public static void main(String[] args) {
        main();
    }
}

