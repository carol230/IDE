import java.util.Scanner;

public class figura15 {

    public static void imfigura15(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nFigura 15: ");
        System.out.print("\nIngrese el número de términos: ");
        int numterminos = scanner.nextInt();
 
        for (int i = 1; i <= numterminos; i++) {
            int value = 1;

            // Imprimir los valores para cada fila
            for (int j = 1; j <= i; j++) {
                System.out.printf("%-5d", value);
                value = value * (i - j) / j;
            }

            // Ir a la siguiente línea después de imprimir la fila
            System.out.println();
        }
    }

    public static void main(String[] args) {
        imfigura15();
    }
}

