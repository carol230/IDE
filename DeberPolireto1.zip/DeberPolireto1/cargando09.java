import java.util.Scanner;

public class cargando09 {

    // Método principal que simula una carga con un porcentaje que avanza de 5 en 5 hasta llegar al 100%
    public void imcargando09() {
        // Mensaje inicial
        System.out.print("\nCargando 09: ");

        // Solicitar al usuario que ingrese su nombre y apellidos
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nIngrese su nombre y apellidos:");
        String nombreCompleto = scanner.nextLine();

        //Bucle que simula el progreso de la carga
        System.out.print("Cargando: ");
        for (int i = 5; i <= 100; i += 5) {
            try {
                Thread.sleep(200); // Simula una carga (pausa de 200 milisegundos)
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // Muestra el progreso de la carga en la misma línea
            System.out.print("\r[" + cargarNombre(nombreCompleto, i) + "]" + i + "%");
        }

        // Mensaje de carga completa y saludo al usuario
        System.out.println("\nCarga completa. ¡Hola, " + nombreCompleto + "!");
        
    }

    // Método que devuelve una subcadena de nombreCompleto basada en el porcentaje de carga
    private static String cargarNombre(String nombreCompleto, int porcentaje) {
        int longitud = nombreCompleto.length();
        int caracteresCargados = (porcentaje * longitud) / 100;
        caracteresCargados = Math.min(caracteresCargados, longitud); // Asegura que no se exceda la longitud total
        return nombreCompleto.substring(0, caracteresCargados);
    }

    // Método principal que instancia la clase Cargando09 y llama al método de carga
    public static void main(String[] args) {
        cargando09 ocargando09 = new cargando09();
        ocargando09.imcargando09();
    }
}
