/**
 * @author: Ivonne Ayala
 * @version: 1.0
 */
import java.util.Scanner;
public class SerieSeis2 {
    public static void charSerieSeis2( ) {
        // Crea un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el numero de elementos: ");
        int tamanio = scanner.nextInt();
        System.out.println("\n Serie 6.2: ");
        // Conjunto de símbolos alternados en un arreglo
        String sumres[] = {"-", "+","-"};
        for (int i = 0; i < tamanio; i++) {
            // Verifica si el índice es par para imprimir la letra alfabética
            if (i%2==0) {
                // Calcula el carácter correspondiente a la posición actual
                char letra =(char)(97+i);
                // Imprime la letra
                System.out.print(letra + " ");
            } else{
                // Si el índice es impar, utiliza símbolos alternados según la posición actual
                int simb=i%3;
                // Imprime el símbolo alternado
                System.out.print(sumres[simb] + " ");
            }
        }
        System.out.println("\n");
    }
    
    public static void main(String[] args) {
        charSerieSeis2();
    }
}
