import java.util.Random;
import java.util.Scanner;

public class cadena08 {

    // Scanner instance needs to be declared as a class variable
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("\nCADENA DE CARACTERES 08\n ");
        String[] conjunto = {"delira", "lidera", "ballena", "llenaba", "alondra", "ladrona", "españa", "apañes", "Enrique", "quieren"};
        Random random = new Random();
        int indicePalabra = random.nextInt(conjunto.length);
        String palabraOriginal = conjunto[indicePalabra];
        System.out.println("Adivina el anagrama de la palabra: " + palabraOriginal);

        // Juego de adivinanza de anagrama
        int intentos = 0;
        while (intentos < 3) {
            System.out.print("Tu respuesta: ");
            String respuestaUsuario = scanner.nextLine();

            // Verificar si la respuesta del usuario es correcta
            if (respuestaUsuario.equalsIgnoreCase(obtenerAnagrama(palabraOriginal))) {
                System.out.println("¡Correcto! Has adivinado el anagrama.");
                break;
            } else {
                System.out.println("Incorrecto. Intenta de nuevo.");
                intentos++;
            }
        }

        // Mostrar la respuesta correcta si el usuario falla tres veces
        if (intentos == 3) {
            System.out.println("La respuesta correcta es: " + obtenerAnagrama(palabraOriginal));
        }

        // Close the scanner
        scanner.close();
    }

    private static String obtenerAnagrama(String palabra) {
        char[] caracteres = palabra.toCharArray();
        Random random = new Random();
        for (int i = 0; i < caracteres.length; i++) {
            int indiceAleatorio = random.nextInt(caracteres.length);
            char temp = caracteres[i];
            caracteres[i] = caracteres[indiceAleatorio];
            caracteres[indiceAleatorio] = temp;
        }
        return new String(caracteres);
    }

    public static void matriz(String nombre, String apellido, int tamanoMatriz) {
        char[][] matriz = new char[tamanoMatriz][tamanoMatriz];
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                matriz[i][j] = ' ';
            }
        }
        for (int i = 0; i < nombre.length(); i++) {
            matriz[i][i] = nombre.charAt(i);
        }
        for (int i = 0; i < apellido.length(); i++) {
            matriz[i][tamanoMatriz - 1 - i] = apellido.charAt(i);
        }
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }
    }
}

