import java.util.Scanner;

public class figura19 {
    public static void imfigura19() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nFigura 19:");
        System.out.print("\nIngrese el número de términos: ");
        int numterminos = scanner.nextInt();
        for (int i = 1; i <= numterminos; i++) {
            // Imprimir cateto opuesto
            System.out.print("+   ");

            int valor = i;
            for (int j = 3; j <= i; j++) {
                // Imprimir valores de la serie
                System.out.print(valor + "   ");
                valor += (j + 1);
            }

            // Imprimir hipotenusa
            for (int k = 1; k <= i; k++) {
                if (k == i) {
                    System.out.println("*");
                } else {
                    System.out.print("");
                }
            }
        }
    }

    public static void main(String[] args) {
        imfigura19();
    }
}


