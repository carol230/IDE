import java.util.Scanner;

public class serie10 {

    private static int obtenerNumeroTerminos() {
        Scanner sc = new Scanner(System.in);
        System.out.print("\nIntroduce un número entero: ");
        return sc.nextInt();
    }

    public void procesofor() {

        System.out.print("\nSerie usando bucle for:");
        int numterminos = obtenerNumeroTerminos();
        int a = 3;
        for (int i = 1; i <= numterminos; i++) {
            System.out.print(" - " + a);
            a *= 3;
        }
    }

    // Serie usando bucle do while
    public void procesodowhile() {
    
        System.out.print("\n\nSerie usando bucle do while:");
        int numterminos = obtenerNumeroTerminos();
        int a = 3;
        int i = 1;
        do {
            System.out.print(" - " + a);
            a *= 3;
            i++;
        } while (i <= numterminos);
    }

    public void procesowhile(){
        System.out.print("\n\nSerie usando bucle while:");
        int numterminos = obtenerNumeroTerminos();
        int a = 3;
        int i = 1;
        while (i <= numterminos) {
            System.out.print(" - "+a);
            a *= 3;
            i++;
        }
    }

    public static void main(String[] args) throws Exception {
        serie10 oserie10 = new serie10();
        oserie10.procesofor();
        oserie10.procesodowhile();
        oserie10.procesowhile();
    }
}
