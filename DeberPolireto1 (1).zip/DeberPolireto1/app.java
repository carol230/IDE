import java.util.Scanner;

public class app {
    public static Scanner scTerminos = new Scanner(System.in);

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n----- Menú Principal ------\n");
            System.out.println("1. Series Numéricas");
            System.out.println("2. Series de Caracteres");
            System.out.println("3. Figuras");
            System.out.println("4. Cadena de Caracteres");
            System.out.println("5. Loading");
            System.out.println("6. Recursion");
            System.out.println("7. Arrays");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 0:
                    System.out.println("¡Hasta luego!");
                    System.exit(0);
                    break;
                case 1:
                    SeriesNumericasMenu();
                    break;
                case 2:
                    seriesCaracteresMenu();
                    break;
                case 3:
                    figurasMenu();
                    break;
                case 4:
                    cadenaCaracteresMenu();
                    break;
                case 5:
                    loadingMenu();
                    break;
                case 6:
                    recursionMenu();
                    break;
                case 7:
                    arrayMenu();
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
                    break;
            }
        }
    }

    private static void SeriesNumericasMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n----- Menú de Series Numéricas -----\n");
            System.out.println("-Elija el ejercicio del 1 al 11-");
            System.out.println("* 0. Volver al Menú Principal *");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 0:
                    return;
                case 1:
        				
                    break;
                case 2:

                    break;
                case 5:
                serie5 oSerie5= new serie5(); 
                oSerie5.showSerie5();
                break;
                case 6:
                serie6 oSerie6= new serie6(); 
                oSerie6.showSerie6();
                break;
                case 7:
                    System.out.println("SERIE 7");
                    System.out.println("Cuantos elementos desea generar?");
					int nroTerminos = scanner.nextInt();
       				Serie7 oSerie7 = new Serie7();

      				System.out.println("Serie con ciclo For");
                    oSerie7.serie7For(nroTerminos);

        			System.out.println();
        			System.out.println("Serie con ciclo While");
        			oSerie7.serie7While(nroTerminos);

        			System.out.println();
       				System.out.println("Serie con ciclo Do-While");
        			oSerie7.serie7Dowhile(nroTerminos);
                    System.out.println();
                    break;
                case 8:
                    System.out.println("SERIE 8");
                    System.out.println("Cuantos elementos desea generar?");
					nroTerminos = scanner.nextInt();
        			Serie8 oSerie8 = new Serie8();

        			System.out.println("Serie con ciclo For");
        			oSerie8.serie8For(nroTerminos);

       				System.out.println();
       				System.out.println("Serie con ciclo While. ");
       				oSerie8.serie8While(nroTerminos);

                    System.out.println();
       				System.out.println("Serie con ciclo Do-While");
        			oSerie8.serie8Dowhile(nroTerminos);
                    System.out.println();
                    break;
                case 9:
                serienueve oSerienueve= new serienueve();
                oSerienueve.procesofor();
                oSerienueve.procesodowhile();
                oSerienueve.procesowhile();
                    break;
                case 10:
                serie10 oserie10 = new serie10();
                oserie10.procesofor();
                oserie10.procesodowhile();
                oserie10.procesowhile();
                    break;
                case 11:
                serie11 oserie11 = new serie11();
                oserie11.procesofor();
                oserie11.procesodowhile();
                oserie11.procesodowhile();
                    break;
                
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
                    break;
            }
        }
    }

    private static void seriesCaracteresMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n----- Menú de Series de caracteres -----\n");
            System.out.println("-Elija el ejercicio del 1 al 9-");
            System.out.println("* 0. Volver al Menú Principal *");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 0:
                    return;

                case 1:

                    SeriesCaracteres oSeriesCaracteres = new SeriesCaracteres();
			        oSeriesCaracteres.serieCaracteres1();
                    System.out.println();
                    break;

                case 2:
                    
					SeriesCaracteres oSeriesCaracteres2 = new SeriesCaracteres();
        			oSeriesCaracteres2.serieCaracteres2();
					System.out.println();
                    break;

                case 5:
                SerieCinco.charSerieCinco();
                    break;
                case 6:
                SerieSeis.charSerieSeis();
                SerieSeis2.charSerieSeis2();
                    break;
                case 7:
                    break;
                case 8:
                    break;
                case 9:
                serie09 serie = new serie09();
                serie.generarSerie();
                    break;

                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
                    break;
            }
        }
    }

    private static void figurasMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n----- Menú de Figuras -----\n");
            System.out.println("-Elija el ejercicio del 1 al 19-");
            System.out.println("* 0. Volver al Menú Principal *");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 0:
                    return;
                case 1:
    				Figuras oFiguras = new Figuras();
        			oFiguras.Figura1();
                    break;

                case 2:
                    Figuras oFiguras2 = new Figuras();
                    oFiguras2.Figura2();
                    break;

                case 3:
                    Figuras oFiguras3 = new Figuras();
                    oFiguras3.Figura3();
                    break;

                case 4:
                    Figuras oFiguras4 = new Figuras();
                    oFiguras4.Figura4();
                    break;

                case 9:
                Figura9.imprimirFigura9();
                    break;
                case 10:
                Figura10.imprimirFigura10();
                    break;
                case 11:
                Figura11.imprimirFigura11();
                    break;
                case 12:
                    break;
                case 13:
                    break;
                case 14:
                    break;
                case 15:
                figura15.imfigura15();
                    break;
                case 16:
                figura16.imfigura16();
                    break;
                case 17:
                figura17.imfigura17();
                    break;
                case 18:
                figura18.imfigura18();;
                    break;
                case 19:
                figura19.imfigura19();
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
                    break;
            }
        }
    }

    private static void cadenaCaracteresMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n----- Menú de Cadenas -----\n");
            System.out.println("-Elija el ejercicio del 1 al 9-");
            System.out.println("* 0. Volver al Menú Principal *");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 0:
                    return;

                case 1:
                    CadenaCaracteres oCadenaCaracteres = new CadenaCaracteres();
                    oCadenaCaracteres.Cadena1();
                    break;
                
                case 2:
                    CadenaCaracteres oCadenaCaracteres2 = new CadenaCaracteres();
                    oCadenaCaracteres2.Cadena2();
                    break;

                case 5:
                Cadena5.cadena5();
                    break;
                case 6:
                Cadena6.cadena6();
                    break;
                case 7:
                    break;
                case 8:
                    break;
                case 9:
                cadena09.imcadena09();
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
                    break;
            }
        }
    }

    private static void loadingMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n----- Menú de Loadings -----\n");
            System.out.println("-Elija el ejercicio del 1 al 11-");
            System.out.println("* 0. Volver al Menú Principal *");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 0:
                    return;
                case 1:
                    Loadings oLoadings = new Loadings();
                    oLoadings.Loading1();
                    break;

                case 2:

                    break;
                case 3:
                Loading3.loading3();
                    break;
                case 4:
                Loading4.loading4();
                    break;
                case 5:
                    break;
                case 6:
                    break;
                case 7:
                    break;
                case 8:
                    break;
                case 9:
                cargando09 ocargando09 = new cargando09();
                ocargando09.imcargando09();
                    break;
                case 10:
                cargando10 ocargando10 = new cargando10();
                ocargando10.imcargando10();
                    break;
                case 11:
                cargando11 ocargando11 = new cargando11();
                ocargando11.imcargando11();
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
                    break;
            }
        }
    }

    private static void recursionMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n----- Menú de Recursion -----\n");
            System.out.println("-Elija el ejercicio del 1 al 6-");
            System.out.println("* 0. Volver al Menú Principal *");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 0:
                    return;

                case 1:
                    Recursion oRecursion = new Recursion();
					oRecursion.Factorial(); 
                    break;

                case 2:

                    break;
                case 3:
                Recursion3.multi();
                    break;
                case 5:
                recursion05.imrecursion05();
                    break;
                case 6:
                Recursion6.main();
                break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
                    break;
            }
        }
    }


    private static void arrayMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n----- Menú de Arrays -----\n");
            System.out.println("-Elija el ejercicio del 1 al 6-");
            System.out.println("* 0. Volver al Menú Principal *");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 0:
                    return;

                case 1:
                    Arreglos oArreglo = new Arreglos();
       				oArreglo.Arreglo1();
                    break;
                    
                case 2:

                    break;
                case 3:
                Array3.main();
                break;
                case 5:
                break;
                case 6:
                break;
                
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
                    break;
            }
        }
    }
}




