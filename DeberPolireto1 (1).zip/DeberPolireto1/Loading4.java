/**
 * @author: Ivonne Ayala
 * @version: 1.0
 */
public class Loading4 {

    public static void loading4(){
        System.out.println("\n Loading 4: ");
        for (int i=1;i<=21;i++){
            // Crea un StringBuilder para construir la barra animada
            StringBuilder barra = new StringBuilder();
             // El bucle esta definido en tres veces para construir la barra con animación
            for (int j=0;j<3;j++){
                // Decide qué carácter usar en la posición actual de la animación
                if (j == (i%3)) {
                    barra.append("0");
                } else {
                    barra.append("o");
                }
            }
            // Calcula el porcentaje de carga
            int porcentaje=((i-1)*5) ;
            // Imprime el indicador de carga en la misma línea usando \r 
            System.out.print("\r"+barra+" "+porcentaje+"%");
            // Pausa la ejecución durante 500 milisegundos para simular la actualización del indicador
            {
                try{
			        Thread.sleep(500);
		            }catch(InterruptedException e){
			            e.printStackTrace();
		            }
	        }
        }
        System.out.println("\n");
    }

    public static void main(String[] args) {
        loading4();
    }
}

