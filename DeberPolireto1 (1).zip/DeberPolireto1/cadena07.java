import java.util.Scanner;

public class cadena07 {

    public static void main(String[] args) {
        System.out.println("\nCADENA DE CARACTERES 07\n ");
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese una frase: ");
        String frase = scanner.nextLine(); // Use nextLine() to capture the entire line

        // Convertir la frase a mayúsculas y eliminar la letra 'J'
        String resultado = convertirMayusculasYEliminarJ(frase);
        System.out.println("Salida: " + resultado);

        scanner.close(); // Close the scanner
    }

    public static String convertirMayusculasYEliminarJ(String input) {
        // Convert the input string to uppercase and eliminate the letter 'J'
        return input.toUpperCase().replace("J", "");
    }

    public static int factorial(int num) {
        if (num <= 1) {
            return 1;
        } else {
            return num * factorial(num - 1);
        }
    }
}


