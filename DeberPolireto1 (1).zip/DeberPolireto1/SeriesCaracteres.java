/**
 * SERIES DE CARACTERES 
 * S1:  + - + - + - + ...      
*  S2:  + + ++ +++ +++++ ++++++++ +++++++++++++ ...
 * @author: Alexis Bautista
 * @since: 04/12/2023
 * @version: 1.0
 */
public class SeriesCaracteres {
    
        public void serieCaracteres1(){    

        //Declaracion de variables
        char caracteres[] = {'+','-'};

        //Ingreso de datos
        System.out.println("\nSERIE 1");
        System.out.println("Ingrese el numero de terminos a generar: ");
        String terminos = debermain.scTerminos.nextLine();

        //Operacion
        for (int i=0;i<Integer.parseInt(terminos);i++){
            if((i%2)==0)
                System.out.print(caracteres[0]);
                else
                    System.out.print(caracteres[1]);
        }
    }

    public void serieCaracteres2(){

        //Declaracion de variables
        char caracteres[] = {'+'};

        //Ingreso de datos
        System.out.println("\n");
        System.out.println("SERIE 2");
        System.out.println("Ingrese el numero de terminos a generar: ");
        String terminos = debermain.scTerminos.nextLine();

        //Operacion (Serie de Fibonaci: se añade un numero que es la suma de los dos)
        int i = 0, numeroant=0, numeroact=1, numerosig=0; 
        while (i<Integer.parseInt(terminos)) {
            for (int j = 0; j < numeroact; j++) {
                System.out.print(caracteres);
            }
           System.out.print(" ");
           numerosig=numeroact+numeroant;
           numeroant=numeroact;
           numeroact=numerosig;
           i++;
        }
    }
}
