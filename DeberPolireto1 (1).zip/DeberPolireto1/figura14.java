import java.util.Scanner;

public class figura14 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un valor numérico: ");
        int n = scanner.nextInt();
        generarFigura14(n);
    }

    public static void generarFigura14(int n) {
        for (int i = 0; i < n; i++) {
            // Imprimir espacios en blanco
            for (int j = 0; j < n - i; j++) {
                System.out.print("  ");
            }
            // Calcular y imprimir los valores en cada fila
            for (int j = 0; j <= i; j++) {
                System.out.print(generarFigura14Valor(i, j) + "    ");
            }
            System.out.println();
        }
    }

    // Método para calcular el valor en cada posición
    public static int generarFigura14Valor(int row, int col) {
        if (col == 0 || col == row) {
            return 1;
        } else {
            return generarFigura14Valor(row - 1, col - 1) + generarFigura14Valor(row - 1, col);
        }
    }
}
