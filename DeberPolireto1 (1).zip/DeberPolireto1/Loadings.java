/**
 * LOADINGS
 * @author: Alexis Bautista
 * @since: 04/12/2023
 * @version: 1.0
 */
public class Loadings {

     public void Loading1(){

        String signos[] = {"\\","|","/","-"};
        
        System.out.println("\nLOADING 1");
        for(int i=0;i<=100;i++){
            String c = signos[i%4]; //Buscamos multiplos de 4 
            System.out.print(" \r" + c + " "+ i +"% cargado");  //\r retorno al inicio 
                                                        //" "+ i +" " para que aparezcan los numeros de carga
            try {Thread.sleep(150); // para ejecutar sierto tiempo los caracteres
            }catch (InterruptedException ie){}
        }
        System.out.println();
    }
}
