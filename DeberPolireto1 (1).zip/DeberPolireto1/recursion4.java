import java.util.Scanner;
public class recursion4 {
    public static void main(String[] args) {
        System.out.println("\nRECURSION 04\n ");
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Ingresa la base (a): ");
        int base = scanner.nextInt();
        
        System.out.print("Ingresa el exponente (b): ");
        int exponente = scanner.nextInt();
        
        int rs = calcularPotencia(base, exponente);
        System.out.println("El resultado de " + base + " elevado a la " + exponente + " es: " + rs);
        scanner.close();
    }
    public static int calcularPotencia(int base, int exponente) {
        if (exponente == 0) {
            return 1; // Cualquier número elevado a 0 es 1
        } else {
            return base * calcularPotencia(base, exponente - 1);
        }
    }
}

