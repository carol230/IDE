/**
 * @author: Ivonne Ayala
 * @version: 1.0
 */
import java.util.Scanner;
public class Recursion6 {
    public static void main(){
        System.out.println("\n Cadena 5: ");
        // Crea un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el numero de su cuenta regresiva: ");
        int conteoRegresivo = scanner.nextInt();
        System.out.println("\n Recursion 6 : ");
        // Llama al método de conteo regresivo
        conteoRegresivo(conteoRegresivo);
        System.out.println("\n");
    }


    private static void conteoRegresivo(int dato){
         // Caso base: si el dato es menor que 0, se detiene la recursión
        if(dato<0){
            return;
        }else{
            // Imprime el número actual
            System.out.println("Numero "+dato);
             // Llamada recursiva: realiza el conteo regresivo reduciendo el dato en 1
            conteoRegresivo(dato-1);
        }
    }
} 
