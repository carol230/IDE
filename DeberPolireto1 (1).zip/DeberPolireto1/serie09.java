import java.util.Scanner;

public class serie09 {

    // Método para generar la serie
    public void generarSerie() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nSerie 09: ");
        System.out.print("\nIngrese el número de términos para la serie: ");
        int numTerminos = scanner.nextInt();
        char letra = 'a';

        // Bucle externo para controlar el número de filas
        for (int i = 1; i <= numTerminos; i++) {

            // Bucle interno para imprimir la letra actual i veces
            for (int j = 0; j < i; j++) {
                System.out.print(letra);
            }

            // Cambiar a println para pasar a la siguiente línea después de cada fila
            System.out.println();

            // Pasar a la siguiente letra en el alfabeto
            letra++;
        }
    }

    public static void main(String[] args) {
        // Crear una instancia de la clase Serie09
        serie09 serie = new serie09();
        serie.generarSerie();
    }

}


