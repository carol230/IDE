import java.util.Scanner;

public class cadena09 {

    // Método para realizar la transformación de mayúsculas y minúsculas alternadas en una cadena
    public static String imcadena09() {
        // Crear un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario que ingrese una frase
        System.out.print("\nCadena 09: ");
        System.out.print("\nIngresa una frase: ");
        String frase = scanner.nextLine();  // Leer la frase ingresada por el usuario

        // Convertir la cadena de entrada en un arreglo de caracteres
        char[] caracteres = frase.toCharArray();

        // Variable para alternar entre mayúscula y minúscula
        boolean mayuscula = true;

        // Iterar a través de cada carácter en el arreglo
        for (int i = 0; i < caracteres.length; i++) {
            // Verificar si el carácter es una letra
            if (Character.isLetter(caracteres[i])) {
                // Alternar entre mayúscula y minúscula para cada letra
                if (mayuscula) {
                    caracteres[i] = Character.toUpperCase(caracteres[i]);
                } else {
                    caracteres[i] = Character.toLowerCase(caracteres[i]);
                }
                // Cambiar el estado para la próxima iteración
                mayuscula = !mayuscula;
            }
        }

        // Construir la cadena resultante a partir del arreglo de caracteres modificado
        String resultado = new String(caracteres);

        // Imprimir el resultado en la consola
        System.out.println("Resultado: " + resultado);

        // Devolver la cadena resultante
        return resultado;
    }
    
    public static void main(String[] args) {

        imcadena09();
    }
}
