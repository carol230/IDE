import java.util.Random;
import java.util.Scanner;

public class array04 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.err.println("\nARRAY 04\n ");
        System.out.print("Ingrese su nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese su apellido: ");
        String apellido = scanner.nextLine();
        int tamanoMatriz = Math.max(nombre.length(), apellido.length());

        // Call the matriz and obtenerAnagrama methods
        matriz(nombre, apellido, tamanoMatriz);
        String anagrama = obtenerAnagrama(nombre + apellido);
        System.out.println("Anagrama: " + anagrama);

        // Close the scanner
        scanner.close();
    }

    public static String obtenerAnagrama(String palabra) {
        char[] caracteres = palabra.toCharArray();
        Random random = new Random();
        for (int i = 0; i < caracteres.length; i++) {
            int indiceAleatorio = random.nextInt(caracteres.length);
            char temp = caracteres[i];
            caracteres[i] = caracteres[indiceAleatorio];
            caracteres[indiceAleatorio] = temp;
        }
        return new String(caracteres);
    }

    public static void matriz(String nombre, String apellido, int tamanoMatriz) {
        char[][] matriz = new char[tamanoMatriz][tamanoMatriz];
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                matriz[i][j] = ' ';
            }
        }
        for (int i = 0; i < nombre.length(); i++) {
            matriz[i][i] = nombre.charAt(i);
        }
        for (int i = 0; i < apellido.length(); i++) {
            matriz[i][tamanoMatriz - 1 - i] = apellido.charAt(i);
        }
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }
    }
}

