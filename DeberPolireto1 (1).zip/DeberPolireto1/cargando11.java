public class cargando11 {
    
    public void imcargando11 (){
  
        System.out.print("\nCargando 11:");
                // Figura original
        String figura = "   \\|||/\n   (> <)\nooO-(_)-Ooo";

        System.out.println("Figura original:\n" + figura);

        // Esperar un momento
        esperar(1000);

        // Desplazar a la derecha y regresar a la posición original
        for (int i = 0; i < 10; i++) { // Aumenta el número de iteraciones para un mayor desplazamiento
            borrarConsola();
            figura = desplazarDerecha(figura);
            System.out.println("Figura desplazada a la derecha:\n" + figura);
            esperar(500); // Pequeña pausa entre movimientos

            borrarConsola();
            figura = regresar(figura);
            System.out.println("Figura regresada:\n" + figura);
            esperar(500); // Pequeña pausa entre movimientos
        }
    }
    // Método para desplazar la figura a la derecha
    private static String desplazarDerecha(String figura) {
        String[] lineas = figura.split("\n");
        StringBuilder resultado = new StringBuilder();

        for (String linea : lineas) {
            resultado.append("  ").append(linea).append("\n"); // Aumenta el número de espacios para un mayor desplazamiento
        }

        return resultado.toString();
    }

    // Método para regresar la figura a la posición original
    private static String regresar(String figuraDesplazada) {
        String[] lineas = figuraDesplazada.split("\n");
        StringBuilder resultado = new StringBuilder();

        for (String linea : lineas) {
            resultado.append(linea.substring(2)).append("\n"); // Ajusta el índice de la substring para un mayor desplazamiento
        }

        return resultado.toString();
    }

    // Método para crear una pausa en milisegundos
    private static void esperar(int milisegundos) {
        try {
            Thread.sleep(milisegundos);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Método para borrar la consola
    private static void borrarConsola() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    public static void main(String[] args) {
        cargando11 ocargando11 = new cargando11();
        ocargando11.imcargando11();
    }
    
}
