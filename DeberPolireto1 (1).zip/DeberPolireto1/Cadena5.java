/**
 * @author: Ivonne Ayala
 * @version: 1.0
 */

import java.util.Scanner;
public class Cadena5{
public static void cadena5(){
        System.out.println("\n Cadena 5: ");
        // Crea un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese una frase/palabra: ");
        // Lee la frase ingresado por el usuario
        String frase = scanner.nextLine();

        // Crea un objeto StringBuilder a partir de la frase.Le da la vuelta y lo deja en minusculas
        StringBuilder resultado = new StringBuilder(frase.toLowerCase()).reverse();

        // El bucle se define sobre cada carácter en el resultado invertido
        for (int i=0;i<resultado.length();i++) {
            // Obtiene el carácter en la posición i
            char c = resultado.charAt(i);
            switch (c) {
                case 'a':
                case 'e':
                case 'i':
                case 'o':
                case 'u':
                // Si es una vocal, convierte el carácter a mayúscula
                    resultado.setCharAt(i,Character.toUpperCase(c));
                    break;
            }
        }
        System.out.println(resultado);
        System.out.println("\n");
    }

    public static void main(String[] args) {
        cadena5();
    }
}

