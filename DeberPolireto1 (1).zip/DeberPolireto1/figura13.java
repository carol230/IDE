import java.util.Scanner;

public class figura13 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un valor numérico: ");
        int n = scanner.nextInt();
        generarFigura13(n);
    }
    public static void generarFigura13(int n) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(j);
            }
            System.out.println();
        }
    }
}