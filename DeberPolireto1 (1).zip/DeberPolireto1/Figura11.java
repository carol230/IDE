/**
 * @author: Ivonne Ayala
 * @version: 1.0
 */
import java.util.Scanner;
public class Figura11 {
    public static void imprimirFigura11(){
        System.out.println("Figura 11: ");
        // Crea un objeto Scanner para leer la entrada del usuario
        Scanner scanner=new Scanner(System.in);
        System.out.print("Ingrese el numero de niveles: ");
        
        // Lee el número de niveles ingresado por el usuario
        int niveles=scanner.nextInt();

        // Carácter que se va a imprimir en la figura
        String guion="_";
        
        // Número de espacios anteriores inicializado en 0
        int espaciosAnteriores=0;

        // El bucle se define a través de los niveles de la figura
        for (int i=1;i<=niveles;i++){
            // Calcula la cantidad de espacios antes de la barra vertical
            int espacios=espaciosAnteriores+(i*2);

            // Imprime los espacios antes de la barra vertical
            for (int j=1; j<espacios;j++){
                System.out.print(" ");
            }

            // Imprime la barra vertical y el carácter guion
            System.out.print("| "+guion);

            // Imprime los guiones adicionales
            for (int k=1;k<i;k++){
                System.out.print(" "+guion);
            }

            // Salto de línea al final de cada nivel
            System.out.println();

            // Actualiza el número de espacios anteriores para el próximo nivel
            espaciosAnteriores=espacios;
        }
        System.out.println("\n");
    }
        public static void main(String[] args) {
            imprimirFigura11();
        }
}   

