
public class loading5 {

    public static void main(String[] args) {
        loading05();
    }

    public static void loading05() {
        System.out.println("\nLOADING 05\n ");
        int total = 20; // Total de caracteres en la barra
        int progress = 5; // Porcentaje de progreso inicial
        // Imprimir la barra de progreso inicial
        printProgressBar(progress, total);
        // Simular el progreso cambiando el porcentaje
        for (int i = 0; i < 100; i += 5) {
            try {
                Thread.sleep(500); // Simular alguna tarea que toma tiempo
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            progress += 5;
            printProgressBar(progress, total);
        }
    }

    private static void printProgressBar(int progress, int total) {
        System.out.print("\r[");
        int filled = progress * total / 100;
        for (int i = 0; i < filled; i++) {
            System.out.print("=");
        }
        System.out.print(">");
        for (int i = filled + 1; i < total; i++) {
            System.out.print(" ");
        }
        System.out.print("] " + progress + "%");
    }
}
